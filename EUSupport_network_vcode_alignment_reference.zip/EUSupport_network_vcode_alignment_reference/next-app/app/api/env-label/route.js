import { NextResponse } from 'next/server';

export async function GET(request) {
  const environment =
    process.env.NEXT_PUBLIC_ENV_LABEL ||
    process.env.ENV_LABEL ||
    'development';

  return NextResponse.json({
    environment,
  });
}
