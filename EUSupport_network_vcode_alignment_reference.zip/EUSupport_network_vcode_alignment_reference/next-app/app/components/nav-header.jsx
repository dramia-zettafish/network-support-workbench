'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { getWorkspacesForUser } from '@/lib/workspace-config.js';
import { useTheme } from './theme-provider.jsx';
import { useWorkspace } from './workspace-provider.jsx';

export default function NavHeader() {
  const pathname = usePathname();
  const router = useRouter();
  const envLabel = process.env.NEXT_PUBLIC_ENV_LABEL || 'development';
  const [user, setUser] = useState(null);
  const { activeWorkspace, setActiveWorkspace, setTimezone } = useWorkspace();
  const [menuOpen, setMenuOpen] = useState(false);
  const [tzOpen, setTzOpen] = useState(false);
  const { theme, setTheme } = useTheme();

  useEffect(() => {
    fetch('/api/auth/me')
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => { setUser(data?.user || null); if (data?.user?.timezone) setTimezone(data.user.timezone); })
      .catch(() => setUser(null));
  }, [pathname]);

  const workspaces = getWorkspacesForUser(user);

  useEffect(() => {
    if (!workspaces.length) return;
    if (activeWorkspace && workspaces.find((w) => w.key === activeWorkspace)) return;
    const match = workspaces.find((w) =>
      w.modules.some((m) => m.href === '/' ? pathname === '/' : pathname === m.href || pathname.startsWith(m.href + '/'))
    );
    setActiveWorkspace(match?.key || workspaces[0]?.key || null);
  }, [workspaces, pathname, activeWorkspace]);

  const currentWorkspace = workspaces.find((w) => w.key === activeWorkspace);
  const modules = currentWorkspace?.modules || [];

  async function handleLogout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    setUser(null);
    router.push('/login');
    router.refresh();
  }

  function isActive(href) {
    if (href === '/') return pathname === '/';
    if (pathname === href) return true;
    // Only match prefix if no other module in the current set is a longer match
    if (pathname.startsWith(href + '/')) {
      const longerMatch = modules.some((m) => m.href !== href && m.href.startsWith(href + '/') && pathname.startsWith(m.href));
      return !longerMatch;
    }
    return false;
  }

  if (pathname === '/login') {
    return (
      <nav className="flex items-center justify-between px-8 h-14" style={{ background: 'var(--color-surface)', borderBottom: '1px solid var(--color-border)' }}>
        <div className="flex items-center gap-3">
          <Link href="/" className="text-xl font-bold no-underline hover:text-blue-600" style={{ color: 'var(--color-text-primary)' }}>EU Support</Link>
          <span className="inline-block px-2.5 py-0.5 rounded text-[0.7rem] font-semibold uppercase tracking-wide" style={{ background: 'var(--color-accent-soft)', color: 'var(--color-accent)' }}>{envLabel}</span>
        </div>
      </nav>
    );
  }

  return (
    <header style={{ background: 'var(--color-surface)', borderBottom: '1px solid var(--color-border)' }} className="shadow-sm">
      {/* Top bar */}
      <div className="flex items-center justify-between px-8 h-11" style={{ borderBottom: '1px solid var(--color-border)' }}>
        <div className="flex items-center gap-3">
          <Link href="/" className="text-base font-bold no-underline hover:text-blue-600" style={{ color: 'var(--color-text-primary)' }}>EU Support</Link>
          <span className="inline-block px-2 py-0.5 rounded text-[0.6rem] font-semibold uppercase tracking-wide" style={{ background: 'var(--color-accent-soft)', color: 'var(--color-accent)' }}>{envLabel}</span>
        </div>
        {user && (
          <div className="relative">
            <button onClick={() => setMenuOpen(!menuOpen)} className="text-xs font-medium cursor-pointer hover:text-[var(--color-accent)]" style={{ color: 'var(--color-text-secondary)' }}>
              {user.username} ▾
            </button>
            {menuOpen && (
              <div className="absolute right-0 top-full mt-1 w-56 rounded-lg shadow-lg py-1 z-50" style={{ background: 'var(--color-surface-raised)', border: '1px solid var(--color-border)' }}>
                <button onClick={() => { setTheme(theme === 'dark' ? 'light' : 'dark'); setMenuOpen(false); }} className="w-full text-left px-4 py-2 text-xs hover:brightness-125" style={{ color: 'var(--color-text-secondary)' }}>
                  {theme === 'dark' ? '☀️ Light Mode' : '🌙 Dark Mode'}
                </button>
                <button onClick={() => { setTzOpen(!tzOpen); }} className="w-full text-left px-4 py-2 text-xs hover:brightness-125" style={{ color: 'var(--color-text-secondary)' }}>
                  🕐 Timezone: {user?.timezone || 'America/Chicago'}
                </button>
                {tzOpen && (
                  <div className="px-3 py-2 border-t" style={{ borderColor: 'var(--color-border)' }}>
                    <select
                      defaultValue={user?.timezone || 'America/Chicago'}
                      onChange={async (e) => {
                        const tz = e.target.value;
                        await fetch('/api/auth/timezone', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ timezone: tz }) });
                        setTimezone(tz);
                        setUser({ ...user, timezone: tz });
                        setTzOpen(false);
                        setMenuOpen(false);
                      }}
                      className="w-full text-xs rounded px-2 py-1"
                      style={{ background: 'var(--color-surface)', color: 'var(--color-text-primary)', border: '1px solid var(--color-border)' }}
                    >
                      {['America/New_York','America/Chicago','America/Denver','America/Los_Angeles','America/Anchorage','Pacific/Honolulu','America/Phoenix','UTC'].map(tz => (
                        <option key={tz} value={tz}>{tz.replace('_',' ').replace('America/','').replace('Pacific/','')}{tz==='America/Chicago'?' (CST)':tz==='America/New_York'?' (EST)':tz==='America/Denver'?' (MST)':tz==='America/Los_Angeles'?' (PST)':''}</option>
                      ))}
                    </select>
                  </div>
                )}
                <button onClick={() => { handleLogout(); setMenuOpen(false); }} className="w-full text-left px-4 py-2 text-xs hover:brightness-125" style={{ color: 'var(--color-text-secondary)' }}>
                  Logout
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Level 1: Workspace tabs */}
      {workspaces.length > 0 && (
        <div className="flex items-end px-8 pt-1 overflow-x-auto">
          {workspaces.map((ws) => (
            <button
              key={ws.key}
              onClick={() => { setActiveWorkspace(ws.key); router.push('/'); }}
              className={`px-5 py-2.5 text-[0.9rem] font-semibold border-b-[3px] transition-colors whitespace-nowrap ${activeWorkspace === ws.key ? 'text-[var(--color-accent)] border-[var(--color-accent)]' : 'border-transparent hover:text-[var(--color-text-primary)]'}`}
              style={activeWorkspace !== ws.key ? { color: 'var(--color-text-muted)' } : undefined}
            >
              {ws.label}
            </button>
          ))}
        </div>
      )}

      {/* Level 2: Module tabs */}
      {modules.length > 0 && (
        <div className="flex items-end px-8 overflow-x-auto scrollbar-hide" style={{ background: 'var(--color-surface-raised)', borderTop: '1px solid var(--color-border)' }}>
          {modules.map((mod) => (
            <Link
              key={mod.href}
              href={mod.href}
              className={`px-4 py-2 text-[0.82rem] font-medium no-underline transition-colors border-b-2 whitespace-nowrap ${isActive(mod.href) ? 'text-[var(--color-accent)] font-semibold border-[var(--color-accent)]' : 'border-transparent hover:text-[var(--color-text-primary)]'}`}
              style={!isActive(mod.href) ? { color: 'var(--color-text-muted)' } : undefined}
            >
              {mod.label}
            </Link>
          ))}
        </div>
      )}
    </header>
  );
}
