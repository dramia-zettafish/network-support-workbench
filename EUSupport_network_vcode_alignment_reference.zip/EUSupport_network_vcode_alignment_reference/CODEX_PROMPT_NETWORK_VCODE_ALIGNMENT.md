# Codex Prompt — Network Vcode EUSupport Shell Alignment Pass

We are working in the Network Vcode codebase. A trimmed EUSupport reference package is available for shell/auth/layout patterns only. Use the reference package for structure, not for copying unrelated business workflows.

## Goal

Perform an **EUSupport shell alignment pass** for Network Vcode.

Network Vcode must remain a standalone local/Tailscale-hosted app for now, but it should be reshaped so it can later merge into EUSupport as a `/network` module using EUSupport's Duo NG/auth/session boundary and shared server-side deployment.

This is **not** a full EUSupport migration or merger.

## Why this matters

The future merge is mainly for:

- EUSupport Duo NG authentication for field/network work
- one roof on the server side
- shared deployment/proxy/auth boundary later
- preserving Network Vcode's network operations workflow inside EUSupport eventually

The future merge is **not** about adopting EUSupport Cases, Logistics, Inventory, or Import Tools workflows.

## Hard rules

- Keep Network Vcode standalone and locally hosted for now.
- Keep Docker Compose and Caddy local/Tailscale usage working.
- Do not add real Duo NG auth yet.
- Do not require EUSupport auth APIs in standalone mode.
- Do not copy EUSupport Cases into Network Vcode.
- Do not add Cases as a primary Network Vcode module.
- Do not add Import Tools as a primary Network Vcode module.
- Do not remove or break existing Network Vcode workflows.
- Preserve the current Network Vcode dashboard. It should become the future `/network` landing page when merged.
- Do not rename database tables or enum types in this pass unless absolutely necessary and fully migrated.
- Do not namespace API routes under `/api/network` yet unless every caller is safely updated and smoke-tested. Prefer documenting the future namespace and making API base handling flexible.

## Reference package usage

Use the trimmed EUSupport reference package for:

- top navigation shell pattern
- workspace/module navigation structure
- Tailwind and global design token setup
- theme provider pattern
- workspace provider pattern
- auth boundary shape
- future Duo provider seam
- middleware route-gating pattern
- server/deployment reference

Relevant EUSupport reference files:

- `next-app/app/layout.jsx`
- `next-app/app/components/nav-header.jsx`
- `next-app/app/components/theme-provider.jsx`
- `next-app/app/components/workspace-provider.jsx`
- `next-app/app/components/dashboard-modules.jsx`
- `next-app/app/globals.css`
- `next-app/lib/workspace-config.js`
- `next-app/middleware.js`
- `next-app/lib/auth/*`
- `next-app/lib/auth/providers/future-duo-provider.js`
- `next-app/docs/AUTH-BOUNDARY.md`

Do not blindly copy these files. Adapt the pattern to Network Vcode.

## Target navigation

Standalone now:

```text
/              -> Network Vcode dashboard / operations overview
/tickets       -> Network tickets/work orders
/ups           -> UPS workflow
/noc-responses -> NOC/device response workflow
/field         -> optional only if an actual field workflow is scaffolded
```

Future EUSupport merge target:

```text
/network               -> Network Vcode dashboard / operations overview
/network/tickets       -> Network tickets/work orders
/network/ups           -> UPS workflow
/network/noc-responses -> NOC/device response workflow
/network/field         -> field workflow behind Duo NG, if needed
```

Primary Network Vcode module tabs should be:

```text
Dashboard | Tickets | UPS | NOC Responses
```

Only add `Field Work` if a real field workflow is being scaffolded. Do not add `Cases` or `Import Tools` as primary tabs.

## Dashboard direction

Keep the current Network Vcode dashboard/operations page.

EUSupport's root dashboard is mostly a workspace/module launcher. Network Vcode's dashboard is a real operations dashboard with workflow data. In a future merge, Network Vcode's dashboard should become:

```text
/network
```

So this pass should refactor with that future move in mind:

- Keep the existing dashboard stats and tables.
- Rename `OperationsPage` only if helpful, for example `NetworkDashboardPage` or `NetworkOperationsDashboard`.
- Avoid hardcoding assumptions that the dashboard must always live at `/`.
- Make route paths and navigation easy to prefix with `/network` later.

## Shell/layout tasks

1. Inspect the current Network Vcode frontend structure.
2. Replace the current left-sidebar shell as the primary app frame with an EUSupport-style top navigation shell.
3. Use a top bar with:
   - brand: `Network Vcode`
   - environment badge: `local`, `tailscale`, or `development` from env with sensible default
   - local user label: `Network Team`
   - theme toggle
4. Add workspace/module framing similar to EUSupport:
   - workspace: `Network Technician`
   - modules: Dashboard, Tickets, UPS, NOC Responses
5. Keep workflow components mostly intact unless route splitting is straightforward.
6. Prefer route-level pages if low-risk:
   - `app/page.js`
   - `app/tickets/page.js`
   - `app/ups/page.js`
   - `app/noc-responses/page.js`
7. If route splitting is risky, keep the current tabbed workflow temporarily but still replace the shell and document route splitting as a follow-up.

## Tailwind/design-token tasks

1. Add Tailwind support if missing:
   - `tailwind.config.js`
   - `postcss.config.js`
   - Tailwind imports in `app/globals.css`
   - package dependencies if missing
2. Add `jsconfig.json` with `@/*` alias.
3. Add EUSupport-compatible design tokens to `globals.css`, including:
   - `--color-bg`
   - `--color-surface`
   - `--color-surface-raised`
   - `--color-surface-hover`
   - `--color-border`
   - `--color-border-strong`
   - `--color-text-primary`
   - `--color-text-secondary`
   - `--color-text-muted`
   - `--color-accent`
   - `--color-accent-soft`
   - `--color-success`
   - `--color-warning`
   - `--color-danger`
   - `--color-input-bg`
   - `--color-input-border`
4. Preserve or map existing Network Vcode CSS variables so existing CSS modules do not break.
5. Do not rewrite every CSS module to Tailwind in this pass. Add the foundation and only refactor what is necessary for the shell/layout.

## Auth-seam tasks

Add a clean auth abstraction for standalone mode that can later be swapped for EUSupport Duo NG/session auth.

Suggested shape:

```js
// frontend/lib/auth/currentUser.js
export async function getCurrentUser() {
  return {
    username: 'Network Team',
    displayName: 'Network Team',
    role: 'technician',
    teams: ['network_technicians'],
    timezone: 'America/Chicago',
    authProvider: 'local',
  };
}
```

Client shell can fetch this through a standalone-safe endpoint if needed:

```text
GET /api/auth/me
```

But keep it local/mock in Network Vcode for now. Do not require EUSupport cookies, Duo sessions, or EUSupport DB auth yet.

Document future replacement:

```text
Standalone now: local/mock current user
Future merge: EUSupport Duo NG/session current user
```

## API route future-readiness

Current API routes can remain as-is during this pass.

However, make API calling flexible so future prefixing is easier. For example:

```js
const API_BASE = process.env.NEXT_PUBLIC_NETWORK_API_BASE || '/api';
```

Future merge recommendation:

```text
/api/network/tickets
/api/network/ups-installations
/api/network/ticket-responses
/api/network/dashboard-summary
```

Do not move to `/api/network/*` in this pass unless every frontend caller is updated and smoke-tested.

## Database future-readiness

Do not rename tables or enum types in this pass.

Document future collision risks if merged into the same database:

- generic tables like `tickets`
- generic enum/type names like `status`, `priority`, `device_type`

Recommended future-safe direction:

```text
network_tickets
network_ups_installations
network_device_responses
network_rmas
network_ticket_status
network_priority
network_device_type
```

Or use a dedicated DB schema:

```text
network_vcode.tickets
network_vcode.ups_installations
```

## Documentation tasks

Add or update:

```text
docs/EUSUPPORT_ALIGNMENT_NOTES.md
```

Include:

1. Current standalone purpose.
2. Why Network Vcode is staying standalone for now.
3. Future merge reason: Duo NG auth + shared server deployment.
4. What was aligned from EUSupport:
   - shell/top nav
   - workspace/module navigation
   - Tailwind/design tokens
   - auth seam
   - future route/API prefix direction
5. What was intentionally not copied:
   - Cases
   - Logistics
   - Inventory
   - Import Tools as primary navigation
   - real Duo/auth enforcement
6. Current standalone routes.
7. Future EUSupport routes under `/network`.
8. Current API routes and future `/api/network/*` recommendation.
9. Database naming risks and future-safe options.
10. Smoke test results.

Update README if needed with local/Tailscale notes:

- standalone local app
- intended team access over Tailscale
- not production-authenticated yet
- future EUSupport merge will handle Duo NG/auth

## Acceptance criteria

- `docker compose up --build` still works.
- Caddy still serves Network Vcode locally.
- Existing workflows still load and save data.
- The left sidebar is removed or no longer used as the main shell.
- Top navigation follows the EUSupport-style pattern.
- Network Vcode dashboard is preserved.
- Primary navigation is Dashboard, Tickets, UPS, NOC Responses.
- No Cases module is added.
- No Import Tools primary module is added.
- Standalone mode does not depend on EUSupport auth.
- A local/mock current-user auth seam exists for future Duo NG replacement.
- API calls still default to `/api`.
- Future `/network` and `/api/network/*` migration path is documented.
- Database naming collision risks are documented, not prematurely changed.
- Build/lint checks are run if available. If lint is not configured, say so clearly.
- Any skipped or risky route split is documented as a follow-up rather than forced.

## Final response from Codex should include

- Summary of files changed.
- Whether route-level splitting was completed or deferred.
- Whether Tailwind was added successfully.
- How the auth seam was implemented.
- Smoke test/build results.
- Any remaining risks or follow-up tasks.
