# EUS Support — DEV Deployment

DEV runs alongside production on the same VM. It uses a separate Docker Compose project, database, volumes, and port.

## Quick Reference

| | Production | DEV |
|---|---|---|
| Compose file | `docker-compose.inventory-prod.yml` | `docker-compose.dev.yml` |
| Env file | `.env` | `.env.dev` |
| Project name | `eusupport` | `eusupport_dev` |
| URL | https://EUSupport.netsync.com (port 443) | http://10.214.30.244:18003 |
| DB volume | `eusupport_api_pg_data` | `eusupport_dev_dev_api_pg_data` |
| Containers | `webstack-api-pg`, `webstack-api-pg-db`, `webstack-caddy` | `dev-api-pg`, `dev-api-pg-db`, `dev-nextjs` |
| SMTP | Enabled | Disabled |
| UI banner | None | Red "DEVELOPMENT ENVIRONMENT" banner |

## Deploy / Update

```bash
./deploy-dev.sh
```

This fetches the latest `develop` branch, rebuilds, starts the DEV stack, and verifies the health endpoint.

## Manual Commands

All DEV commands use the `-p eusupport_dev` project flag to isolate from production.

```bash
# Start
docker compose -p eusupport_dev -f docker-compose.dev.yml --env-file .env.dev up -d --build

# Stop (DEV only — production is untouched)
docker compose -p eusupport_dev -f docker-compose.dev.yml --env-file .env.dev down

# Logs
docker compose -p eusupport_dev -f docker-compose.dev.yml logs -f

# Status
docker compose -p eusupport_dev -f docker-compose.dev.yml ps

# Verify health
curl http://10.214.30.244:18003/healthz

# Rebuild after code changes
docker compose -p eusupport_dev -f docker-compose.dev.yml --env-file .env.dev up -d --build
```

## Wipe DEV Data (reset database)

```bash
docker compose -p eusupport_dev -f docker-compose.dev.yml down -v
./deploy-dev.sh
```

The `-v` flag removes the DEV database volume. Production volumes are not affected.

## Environment File

Copy `.env.dev` and update secrets as needed. Key differences from production:
- `INVENTORY_PG_DB=inventory_dev` — separate database
- `SMTP_HOST=` — empty, disables all email
- `ENV_LABEL=DEVELOPMENT ENVIRONMENT - TEST DATA ONLY` — triggers the red UI banner
- `JWT_SECRET` — different from production (DEV tokens won't work in prod and vice versa)

`.env.dev` is gitignored. Do not commit it.

## Database

The system is **Postgres-only**. There is no SQLite support. All migrations, tests, and
runtime code target PostgreSQL exclusively.

- Schema is created automatically on startup by idempotent migration scripts
- `migrate_core_schema.py` creates all 41 base tables and seeds 11 teams
- `migrate_case_management.py`, `migrate_workbook_modules.py`, `migrate_shipping_carriers.py` create module-specific tables
- Legacy SQLite scripts are archived in `dev/app/tools/_archived_sqlite/` — do not use

## Running Tests

Tests run against the DEV Postgres database:

```bash
# Ensure DEV stack is running
docker compose -p eusupport_dev -f docker-compose.dev.yml --env-file .env.dev up -d

# Run all tests
TEST_DB_URL="postgresql+asyncpg://inventory_dev:dev_change_me_now@localhost:5432/inventory_dev" \
  python -m unittest discover dev/app/ -p "test_*.py"

# Run a single test file
TEST_DB_URL="postgresql+asyncpg://inventory_dev:dev_change_me_now@localhost:5432/inventory_dev" \
  python -m unittest dev/app/test_cart.py
```


## Next.js DEV Service

The Next.js UI runs as an isolated container service in the DEV stack. It provides a modern frontend for the inventory management system with read-only database access.

| Property | Value |
|---|---|
| Container name | `dev-nextjs` |
| Host port | `18004` |
| URL | http://10.214.30.244:18004 |
| Build context | `next-app/` |
| Dockerfile | `next-app/Dockerfile.dev` |
| Auth mode | `mock` (no real authentication in DEV) |

### Start / Stop / Rebuild

```bash
# Start full DEV stack (includes Next.js service)
docker compose -p eusupport_dev -f docker-compose.dev.yml up -d --build

# Stop full DEV stack
docker compose -p eusupport_dev -f docker-compose.dev.yml down

# Rebuild only the Next.js service
docker compose -p eusupport_dev -f docker-compose.dev.yml up -d --build nextjs_dev

# View Next.js logs
docker compose -p eusupport_dev -f docker-compose.dev.yml logs -f nextjs_dev

# View all service logs
docker compose -p eusupport_dev -f docker-compose.dev.yml logs -f

# Check service status
docker compose -p eusupport_dev -f docker-compose.dev.yml ps
```

### Validation Commands

```bash
# Health check
curl http://localhost:18004/api/health
# Expected: {"status":"ok"}

# Database health
curl http://localhost:18004/api/db-health
# Expected: {"status":"ok"}

# Parts endpoint (mock auth)
curl http://localhost:18004/api/parts
# Expected: JSON array of parts data

# Stock endpoint (mock auth)
curl http://localhost:18004/api/stock
# Expected: JSON array of stock data

# Inventory page
curl -I http://localhost:18004/inventory
# Expected: HTTP 200
```
