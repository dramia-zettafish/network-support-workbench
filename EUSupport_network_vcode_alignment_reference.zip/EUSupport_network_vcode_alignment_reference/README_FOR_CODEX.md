# EUSupport Reference Package for Network Vcode Alignment

This package is intentionally trimmed. Use it as a reference for the Network Vcode alignment pass without wasting Codex context on the entire EUSupport app.

## Goal

Use these files to make Network Vcode look and behave more like an EUSupport-shaped standalone module while keeping Network Vcode independent for now.

The future merge goal is **not** to adopt EUSupport Cases, logistics, inventory, or import workflows. The future merge goal is:

- use EUSupport's Duo NG/auth/session boundary for field/network work
- keep Network Vcode under the same server-side deployment later
- preserve Network Vcode's own network operations workflows
- avoid maintaining a separate long-term app/auth/server stack

## Files included

### Shell / layout / top navigation

- `next-app/app/layout.jsx`
- `next-app/app/page.jsx`
- `next-app/app/components/nav-header.jsx`
- `next-app/app/components/theme-provider.jsx`
- `next-app/app/components/workspace-provider.jsx`
- `next-app/app/components/dashboard-modules.jsx`
- `next-app/app/components/access-denied-banner.jsx`

Use these as structure references for top bar, workspace bar, module bar, theme handling, and dashboard module-card styling.

### Tailwind / design tokens

- `next-app/app/globals.css`
- `next-app/tailwind.config.js`
- `next-app/postcss.config.js`
- `next-app/jsconfig.json`
- `next-app/package.json`

Use these for Tailwind setup, CSS variable naming, theme variables, and `@/*` import alias direction.

### Workspace/module config

- `next-app/lib/workspace-config.js`

Use this to understand EUSupport's workspace-driven navigation model. For Network Vcode standalone, create a local equivalent with only:

- Dashboard
- Tickets
- UPS
- NOC Responses
- optional Field Work only if a field workflow is actually scaffolded

Do not add Cases or Import Tools as Network Vcode primary modules.

### Auth / Duo seam / route gating

- `next-app/middleware.js`
- `next-app/lib/auth/*`
- `next-app/lib/auth/providers/*`
- `next-app/app/api/auth/*`
- `next-app/app/login/page.jsx`
- `next-app/docs/AUTH-BOUNDARY.md`

Use these to understand the auth boundary and future Duo provider seam. Do **not** add real EUSupport auth to standalone Network Vcode during the alignment pass. Instead, add a clean local/mock current-user abstraction that can later be swapped for EUSupport Duo NG/session auth.

### Server/deployment reference

- root `Caddyfile`
- root `docker-compose.dev.yml`
- root `docker-compose.inventory-prod.yml`
- root `.env.dev.ubuntu.example`
- `next-app/Dockerfile.dev`
- `next-app/.env.local.example`

Use these only as reference for later server-side consolidation. Do not change Network Vcode's current local/Tailscale Docker/Caddy flow unless needed for the standalone alignment pass.

## What was intentionally excluded

The full EUSupport app contains many modules that are not needed for this task. Excluded areas include Cases, Logistics, Inventory, Ledger, Route Coordination, Admin data screens, generated documentation, old Python/dev code, and unrelated module APIs.

## Key implementation guidance

Network Vcode should become:

- standalone now
- EUSupport-shaped visually and structurally
- future-ready for `/network` and `/api/network/*`
- future-ready for EUSupport Duo NG/session auth
- still owned by its existing Network Vcode workflows

Standalone route target now:

```text
/              -> Network Vcode dashboard
/tickets       -> Tickets workflow
/ups           -> UPS workflow
/noc-responses -> NOC/device response workflow
/field         -> optional future field workflow only if scaffolded intentionally
```

Future EUSupport merge target:

```text
/network               -> Network Vcode dashboard
/network/tickets       -> Tickets workflow
/network/ups           -> UPS workflow
/network/noc-responses -> NOC/device response workflow
/network/field         -> field workflow behind Duo NG, if needed
```
